package com.example.appmanprobaru

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.fragment.app.Fragment
import btn_event_active
import btn_home_active
import com.google.android.material.bottomnavigation.BottomNavigationView

class EventActivity : AppCompatActivity() {

    private lateinit var bottomNav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_screen_with_navbar)

        bottomNav = findViewById(R.id.bot_nav_static)
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.bottom_navbar_home -> {
                    loadFragment(btn_home_active())
                    true
                }
                R.id.bottom_navbar_live -> {
                    loadFragment(btn_live_active())
                    true
                }
                R.id.bottom_navbar_events -> {
                    loadFragment(btn_event_active())
                    true
                }
                R.id.bottom_navbar_profile -> {
                    loadFragment(btn_profile_active())
                    true
                }
                else -> {
                    false
                }
            }
        }

    }

    private fun loadFragment(fragment: Fragment) {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.Main_fragment, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }


}
