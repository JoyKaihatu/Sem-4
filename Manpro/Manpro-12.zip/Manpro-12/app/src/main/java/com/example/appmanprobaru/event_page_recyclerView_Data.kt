package com.example.appmanprobaru

data class event_page_recyclerView_Data(
    val titleImage: Int, val titleText:String


) {
}
