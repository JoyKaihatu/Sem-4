package com.example.appmanprobaru

import android.widget.Button

data class home_page_recyclerView_Data(val titleImage: Int, val titleText:String){

}
