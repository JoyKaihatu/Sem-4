package com.example.appmanprobaru

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class rvEvent_adapter(private val event_page_recyclerView_Data: ArrayList<home_page_recyclerView_Data>): RecyclerView.Adapter<rvEvent_adapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.event_box_layout, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = event_page_recyclerView_Data[position]
        holder.image1.setImageResource(currentItem.titleImage)
        holder.title1.text = currentItem.titleText
    }

    override fun getItemCount(): Int {
        return event_page_recyclerView_Data.size
    }

    class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val image1: ImageView = itemView.findViewById(R.id.rvHome_image)
        val title1: TextView = itemView.findViewById(R.id.rvHome_Title)
    }
}
