package com.example.fall.ui.home

import android.widget.TextView
import androidx.lifecycle.ViewModel
import com.example.fall.R

class HomeViewModel(view: Any) : ViewModel() {

//    private val _text = MutableLiveData<String>().apply {
//        value = "This is home Fragment"
//    }
//    val text: LiveData<String> = _text
//    val btnAddThread =
}